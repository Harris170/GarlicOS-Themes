Step 1: Insert your Micro SD Card with the GarlicOS installed.
Step 2: Put "skin" folder in ROMS Drive/CFW and click "Replace the file in destination"
Step 3: Put "boot_logo.bmp.gz" file in MISC Drive and click "Replace the files in destination"

Boot up and enjoy!